

<?php $__env->startSection('judul', 'Destinasi'); ?>

<?php $__env->startSection('konten'); ?>
<section class="hero is-success">
    <div class="hero-body">
        <p class="title">Destinasi</p>
        <p class="subtitle">Destinasi Wisata Lokal</p>
    </div>
</section>

<section class="section has-background-primary-soft has-text-primary-soft-invert">
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card">
            <div class="card-content">
                <div class="content">
                    <h2><?php echo e($item->nama_destinasi); ?></h2>
                    <i>Lokasi: <?php echo e($item->lokasi->nama_lokasi); ?></i>
                </div>
            </div>
            <footer class="card-footer">
                <a href="/destinasi/<?php echo e($item->id); ?>" class="card-footer-item">
                    Selengkapnya
                </a>
            </footer>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\uas-asmara\resources\views/destinasi/list.blade.php ENDPATH**/ ?>