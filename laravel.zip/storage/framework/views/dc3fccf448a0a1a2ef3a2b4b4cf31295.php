
<?php $__env->startSection('judul', 'Selamat Datang'); ?>

<?php $__env->startSection('konten'); ?>
    <section class="hero">
        <div class="hero-body">
            <p class="title">Selamat Datang</p>
            <p class="subtitle">
                SISTEM INFORMASI DESTINASI WISATA
            </p>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\uas-asmara\resources\views/beranda.blade.php ENDPATH**/ ?>