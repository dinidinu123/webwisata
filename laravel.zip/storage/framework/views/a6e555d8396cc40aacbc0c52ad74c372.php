

<?php $__env->startSection('judul', $data->nama_destinasi); ?>

<?php $__env->startSection('konten'); ?>
<section class="hero is-success">
    <div class="hero-body">
        <p class="title"><?php echo e($data->nama_destinasi); ?></p>
        <p class="subtitle">Lokasi: <?php echo e($data->lokasi->nama_lokasi); ?></p>
    </div>
</section>

<section class="section has-background-primary-soft has-text-primary-soft-invert">
    <div class="card">
        <div class="card-image">
            <figure class="image is-4by3">
                <img src="<?php echo e(asset('storage/' . $data->foto)); ?>" alt="<?php echo e($data->nama_destinasi); ?>">
            </figure>
        </div>
        <div class="card-content">
            <div class="content">
                <?php echo e($data->deskripsi); ?>

            </div>
        </div>
    </div>

    <?php if($data->lampiran): ?>
        <div class="card">
            <div class="card-content">
                <div class="content">
                    <h4>Lampiran</h4>
                    <?php $__currentLoopData = $data->lampiran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lampiran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(asset('storage/' . $lampiran)); ?>" target="_blank"><?php echo e(basename($lampiran)); ?></a><br>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    <?php endif; ?>

</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\uas-asmara\resources\views/destinasi/detail.blade.php ENDPATH**/ ?>