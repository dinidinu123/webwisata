<?php

namespace App\Filament\Resources\DestinasiResource\Pages;

use App\Filament\Resources\DestinasiResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateDestinasi extends CreateRecord
{
    protected static string $resource = DestinasiResource::class;
}
